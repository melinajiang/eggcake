package bank;

public class debitCard extends Card{
	public debitCard(String username){
		super(username);
		//this.username=username;
	}
	protected void withDrawMoney(double money) {
		System.out.println("YOUR REMAINING MONEY IN YOUR CREDIT CARD IS: "+remainingSum);
		System.out.println("THE MAXIMIZE MONEY YOU CAN WITHDRAW IS :"+remainingSum);
		//借记卡手续费为0。
		if (money<=remainingSum) {
			System.out.println("THE SERVICE CHARGE OF THIS WITHDRAW IS :"+money);
			remainingSum=remainingSum-money;
		}
		else{
			System.out.println("YOU CANNT WITHDRAW SO MUCH!");
			System.out.println("THE MAXIMIZE MONEY YOU CAN WITHDRAW IS :"+(remainingSum));
		}
	}
	protected void pay() {
		System.out.println("YOU CANNOT MAKE AN OVERDRAFT WITH THE CREDIT CARD!");
		System.out.println("YOU CANNOT PAY BY INSTALLMENTS WITH THE CREDIT CARD!");
	}
}
