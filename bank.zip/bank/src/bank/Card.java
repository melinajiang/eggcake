package bank;

public abstract class Card {
	String cardNumber="622", username;
	double remainingSum=0;
	double debt=0;
	int i;
	static int cardSum;
	//ArrayList List = new ArrayList();
	public Card(String username) {
		// TODO Auto-generated constructor stub
		
		 this.username=username;
	      for(i=0;i<16;i++){
	    	  cardNumber=cardNumber.concat(String.valueOf((int)(0+Math.random()*10)));
	      }
	}
	protected void depositMoney(double money){
		remainingSum=remainingSum+money;
		System.out.println("YOU HAVE DEPOSIT :"+money);
		getRemainingSum();
	}
	protected void getInformation() {
		System.out.println("THE USRNAME IS : "+username);
		System.out.println("THE CARD NUMBER IS :"+cardNumber);
	}
	protected void getRemainingSum() {
		System.out.println("THE REAMAINING MOMENY IS : "+remainingSum);
	}
	protected abstract void withDrawMoney(double money) ;
	protected abstract void pay() ;
}
