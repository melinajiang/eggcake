package bank;

public class whiteGoldCard extends Card {
	public whiteGoldCard(String username) {
		// TODO Auto-generated constructor stub
		super(username);
		//this.username=username;
	}
	protected void withDrawMoney(double money) {
		System.out.println("YOUR REMAINING MONEY IN YOUR CREDIT CARD IS: "+remainingSum);
		System.out.println("THE MAXIMIZE MONEY YOU CAN WITHDRAW IS :"+(remainingSum+10000-(remainingSum+1000)*0.0005));
		//信用卡手续费为千分之五。
		if ((money*0.0005+money)<=remainingSum) {
			System.out.println("THE SERVICE CHARGE OF THIS WITHDRAW IS :"+money*0.0005);
			remainingSum=remainingSum-money*0.0005;
		}else if((money*0.0005+money)<=(remainingSum+10000)){
			System.out.println("THE SERVICE CHARGE OF THIS WITHDRAW IS :"+money*0.0005);
			debt=money*0.0005+money-remainingSum;
			System.out.println("THE MONEY YOU OWN THE BANK"+debt);
		}else if((money*0.0005+money)>(remainingSum+10000)){
			System.out.println("YOU CANNT WITHDRAW SO MUCH!");
			//System.out.println("THE MAXIMIZE MONEY YOU CAN WITHDRAW IS :"+(remainingSum+10000));
		}
		
	}
	protected void pay() {
		System.out.println("YOU CAN MAKE AN OVERDRAFT WITH THE CREDIT CARD!");
		System.out.println("YOU CAN PAY BY INSTALLMENTS WITH THE CREDIT CARD!");
	}
}
