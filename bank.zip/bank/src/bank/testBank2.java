package bank;

import java.util.InputMismatchException;
import java.util.Scanner;

public class testBank2 {
	private static int num;
	//private static Integer integer;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		administrator a1=new administrator();
		while (true) {	
		System.out.println("                   NOW YOU ARE IN THE CREATING MENU                   ");
		System.out.println("INPUT 1 TO CREAT A CREDIT CARD ACCOUNT");
		System.out.println("INPUT 2 TO CREAT A DEBIT CARD ACCOUNT");
		System.out.println("INPUT 3 TO CREAT A WHITE GOLD CARD ACCOUNT");
		System.out.println("INPUT 0 TO EXIT ");
		splitLine();
		
		String name=" ";
		
		Scanner scanner=new Scanner(System.in);
		try {
			num=scanner.nextInt();
			String i=scanner.nextLine();
		} catch (InputMismatchException e) {
			// TODO: handle exception
			System.out.println("PLEASE INPUT THE RIGHT DATA TYPE\n");
			continue;
		}
				
		if(num==2||num==3||num==1){
		System.out.println("PLEASE INPUT THE NAME U WANT YOUR CARD TO BE REGISTERED UNDER!");
		while(true){
			try {
			name=scanner.nextLine();
			break;
		} catch (InputMismatchException e ) {
			// TODO: handle exception
			System.out.println("PLEASE INPUT THE RIGHT DATA TYPE");
			continue;
		}
		}
		
		if(num==1){
			creditCard creditCardUser=new creditCard(name);
			a1.addUsers(creditCardUser);
			//al.add(creditCardUser);
			userMenu(creditCardUser);
		}
		else if(num==2){
			debitCard debitCardUser=new debitCard(name);
			a1.addUsers(debitCardUser);
			//al.add(debitCardUser);
			userMenu( debitCardUser);
		}
		else if (num==3) {
			whiteGoldCard whiteGoldCardUser=new whiteGoldCard(name);
			a1.addUsers(whiteGoldCardUser);
			//al.add(whiteGoldCardUser);
			userMenu(whiteGoldCardUser);
		}
		}
		else if(num==0){
			//scanner.close(); ???
			System.out.println("                   NOW YOU WILL EXIT THE CREATING MENU                   ");
			splitLine();
			break;
		}else if (num!=2||num!=3||num!=1) {
			System.out.println("PLEASE INPUT THE RIGHT NUMBER IN THE MENU !");
			splitLine();
			continue;
		}
		} 
		/*Card []  array =(Card[]) al.toArray(new  Card[al.size()] );
		System.out.println("ALL THE ACCOUNT INFORMATION IS:");
		splitLine();
		for(int i=0;i<array.length;i++){
			array[i].getInformation();
		}
		*/
		//administrator a1=new administrator(x)
		a1.administratorGetUsers();
		int num;
		while(true){
			Scanner scanner3=new Scanner(System.in);
			try {
				num=scanner3.nextInt();
				scanner3.close();
				break;
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("PLEASE INPUT THE RIGHT DATA TYPE");
				continue;
			}
		}
		a1.administratorGetInformation(num);
}
	private static void userMenu( Card user){
		
	//System.out.println("INPUT 2 TO SEE THE TOTAL ACCOUNT");
	//int num2=9;
	splitLine();
	System.out.println("                   NOW YOU ARE IN THE USER MENU                   ");
	System.out.println("INPUT 2 TO GET THE INFORMATION OF THE ACCOUNT");
	System.out.println("INPUT 3 TO DEPOSIT MONEY");
	System.out.println("INPUT 4 TO WITHDRAW MONEY");
	System.out.println("INPUT 5 TO SEE PAY INFORMATION");
	System.out.println("INPUT 0 TO EXIT THE USER MEUN");
	splitLine();
	while(true){
		Scanner scanner2=new Scanner(System.in);
	try {
		num=scanner2.nextInt();
		//String i=scanner.nextLine();
	} catch (InputMismatchException e) {
		// TODO: handle exception
		System.out.println("PLEASE INPUT THE RIGHT DATA TYPE");
		continue;
		//System.out.println(num2);
	}
	
	if(num==2||num==3||num==4||num==5||num==0){
	if (num==2) {
		user.getInformation();
		user.getRemainingSum();
		splitLine();
	}else if (num==3) {
		System.out.println("PLEASE INPUT THE AMOUNT OF MONEY YOU WANT TO DEPOSIT!");
		double money=scanner2.nextDouble();
		user.depositMoney(money);
		splitLine();
	}else if (num==4) {
		System.out.println("PLEASE INPUT THE AMOUNT OF MONEY YOU WANT TO WITHDRAW!");
		double money=scanner2.nextDouble();
		user.withDrawMoney(money);
		splitLine();
	}else if (num==5) {
		user.pay();
		splitLine();
	}
	else if (num==0) {
		System.out.println("                   NOW YOU WILL EXIT THE USERMENU                   ");
		splitLine();
		//scanner2.close();
		break;
	}
	}
	else {
		System.out.println("PLEASE INPUT THE RIGHT NUMBER IN THE MENU !");
	}
	
	}
}
private static void splitLine() {
	for(int i=0;i<80;i++){
		System.out.print("-");
	}
	System.out.println();
}
}
/*public static void Administors(Card a) {
	Object []  array =(Object[]) al.toArray(new   Object[al.size()] );
	System.out.println("ALL THE ACCOUNT INFORMATION IS:");
	for(int i=0;i<array.length;i++){
		System.out.println(array[i]);
	}
}
}
*/

	/*private static void checkNum(Scanner scanner, creditCard creditCardUser){
	int num;
	//System.out.println("INPUT 2 TO SEE THE TOTAL ACCOUNT");
	System.out.println("INPUT 2 TO GET THE INFORMATION OF THE ACCOUNT");
	System.out.println("INPUT 3 TO DEPOSIT MONEY");
	System.out.println("INPUT 4 TO WITHDRAW MONEY");
	System.out.println("INPUT 5 TO SEE PAY INFORMATION");
	System.out.println("INPUT 0 TO EXIT THE PROGRAMMEE");
	while(true){
	num=scanner.nextInt();
	if(!(num==2&&num==3&&num==4&&num==5&&num==0)){
	if (num==2) {
		creditCardUser.getInformation();
		creditCardUser.getRemainingSum();
	}else if (num==3) {
		System.out.println("PLEASE INPUT THE AMOUNT OF MONEY YOU WANT TO DEPOSIT!");
		double money=scanner.nextDouble();
		creditCardUser.depositMoney(money);
	}else if (num==4) {
		System.out.println("PLEASE INPUT THE AMOUNT OF MONEY YOU WANT TO WITHDRAW!");
		double money=scanner.nextDouble();
		creditCardUser.withDrawMoney(money);
	}else if (num==5) {
		creditCardUser.pay();
	}
	else if (num==0) {
	break;
	}
	}
	else {
		System.out.println("PLEASE INPUT THE RIGHT NUMBER IN THE MEUN !");
	}
	}
	}*/
	/*user.getInformation();
		user.depositMoney(10000);
		user.withDrawMoney(1100);
		user.getRemainingSum();*/
		