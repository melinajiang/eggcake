package bank;

import java.util.ArrayList;

public class administrator {
	public ArrayList<Card>list;
	//int a=list.size();
	public administrator(){
	list=new ArrayList<Card>();
	
	//list.add(x);
	}
	public void addUsers(Card x){
		list.add(x);
	}
	public void administratorGetUsers(){	
		System.out.println("                   YOU ARE NOW IN THE ADMINISTRATOR MEUN                   ");
		
		if (list.size()==0){
			System.out.println("THERE ARE NO USERS");
			
		}

		else{
			System.out.println("THE USERS ARE:");
			for(int i=0;i<list.size();i++){
			System.out.print(i+1+" . ");
			System.out.println(list.get(i).username);
		}
		System.out.println("INPUT THE NUMBER OF THE USER YOU WANT TO SEE INFROMATION WITH !");
		}
		}
	public void administratorGetInformation(int i){
	/*Card []  array =(Card[]) list.toArray(new  Card[list.size()] );
		System.out.println("ALL THE ACCOUNT INFORMATION IS:");
		//splitLine();
		for(int i=0;i<array.length;i++){
			array[i].getInformation();
		}
		*/
		if(i<=list.size()){
		System.out.println("THE USR INFORMATIONS ARE:");
		list.get(i-1).getInformation();
		list.get(i-1).getRemainingSum();
		}
		else{
			System.out.println("PLEASE INPUT THE RIGHT NUMBER OF USER");
		}

	}
	/*private static void splitLine() {
		for(int i=0;i<80;i++){
			System.out.print("-");
		}
		System.out.println();
	}*/
}

